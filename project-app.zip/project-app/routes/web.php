<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//-------------------login page--------------------------//


Route::get('/', function () {
    return view('index1');
});

//-------------------supervisor login--------------------------//


Route::get('/index1', function () {
    return view('index1');
});
Route::post('/logins', 'App\Http\Controllers\LogController@logins');


//-------------------staff login--------------------------//


Route::get('/index1', function () {
    return view('index1');
});
Route::post('/login', 'App\Http\Controllers\LogController@login');

//-------------------staff insert--------------------------//


Route::get('/page2', function () {
    return view('page2');
});
Route::post('/insert', 'App\Http\Controllers\LogController@inst');

//-------------------supervisor view--------------------------//


Route::get('/page1', function () {
    return view('page1');
});
	Route::get('/page1', 'App\Http\Controllers\LogController@view');
	
//-------------------approval--------------------------//	
	Route::get('/approval/{type}', 'App\Http\Controllers\LogController@approval');
	
//-------------------reject--------------------------//
Route::get('/reject/{type}', 'App\Http\Controllers\LogController@reject');

?>
