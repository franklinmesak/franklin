<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;
use Session;

class LogController extends Controller
{

//--------------------supervisor login--------------------------//


       public function logins(Request $request) {
         
   $names = $request->input('emails');
    $passs = $request->input('passwords');   
   $request->session()->put('x', $names); 
   $value = $request->session()->get('x');   
   $sel_user = DB::table('supervisor')
 
   ->where('emails', '=', $names)
   ->where('passwords', '=', $passs)
   ->get()->count(); 
   
if ($sel_user > 0)
 {  

   $data['view'] = DB::table('projects')->get();
		         return view('page1', $data);
}
else
{
return view('index1')->with('failed', 'Please Try Again Later..'); 
}
}

//-------------------staff login--------------------------//

    public function login(Request $request) {
         
   $name = $request->input('email');
    $pass = $request->input('password');   
   $request->session()->put('x', $name); 
   $value = $request->session()->get('x');   
   $sel_user = DB::table('staff')
 
   ->where('email', '=', $name)
   ->where('password', '=', $pass)
   ->get()->count(); 
   
if ($sel_user > 0)
 {  

   return view('page2');
}
else
{
	
return view('index1')->with('faileds', 'Please Try Again Later..'); 
}
}

//-------------------staff insert--------------------------//

public function inst(Request $request) {

   
    $data = array(
        'task' => $request->input('task'), 
        'date' => $request->input('date'),
        'start' => $request->input('start'),
        'end' => $request->input('end'),
       
    );

   
    $lastInsertedId = DB::table('projects')->insertGetId($data); 
return view("page2"); 
}

//-------------------approval--------------------------//

public function approval($id=false) {
	
	$data= array(
	
	        'status' =>"approved",
);
		
	    $data['status']=DB::table('projects')->where('id', $id)->update($data);
        $data['view'] = DB::table('projects')->get();
        return view('page1', $data); 
 

        }

//-------------------reject--------------------------//

public function reject($id=false) {
	
	$data= array(
	
	        'status' =>"rejected",
);
		
	    $data['status']=DB::table('projects')->where('id', $id)->update($data);
        $data['view'] = DB::table('projects')->get();
        return view('page1', $data); 
 

        }

}

?>