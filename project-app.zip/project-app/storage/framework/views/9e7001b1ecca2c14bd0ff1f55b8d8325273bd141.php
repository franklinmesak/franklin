<html>
<head>
<title>form creater</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo e(url('public/assets/css/bootstrap.min.css')); ?>">
<script src="<?php echo e(url('public/assets/js/jquery-3.6.0.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/css/bootstrap.min.js')); ?>"></script>
<style>
*
{
	color:red;
	font-size:20px;
}
#a
{
width:100%;
height:400px;
background-image:url("<?php echo e(url('public/assets/image/progress.jpg')); ?>");
}
#b
{
width:100%;
height:200px;
background-image:url("<?php echo e(url('public/assets/image/pic1.jpg')); ?>");
}
#c
{
width:100%;
height:300px;
background-image:url("<?php echo e(url('public/assets/image/bottom.jpg')); ?>");
}

</style>
</head>
<body>
<div class="container-fluid" id="b">
<center><h1>WELCOME<h1></center>
</div>


<div class="container-fluid" id="a">
<div class="row">
<div class="col-md-6">
<h1>supervisor login</h1>
<?php if(session('failed')): ?>
<div class="alert alert-success">
<?php echo e(session('failed')); ?>

</div>
<?php endif; ?>

   <form action="<?php echo e(url('/logins')); ?>" method="post" enctype="multipart/form-data">
	  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<div class="form-group">
	   <label for="name">EMAIL:</label>
	   <input type="text" name="emails" class="form-control">
	   </div>
<div class="form-group">
	   <label for="name">PASSWORD:</label>
	   <input type="password" name="passwords" class="form-control">
	   </div>
	   <button type="submit"  class="btn btn-danger">LOGIN</button>
	   </form>
</div>




<div class="col-md-6">
<h1>staff login</h1>
	   <?php if(session('faileds')): ?>
<div class="alert alert-success">
<?php echo e(session('faileds')); ?>

</div>
<?php endif; ?>
   <form action="<?php echo e(url('/login')); ?>" method="post" enctype="multipart/form-data">
	  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<div class="form-group">
	   <label for="name">EMAIL:</label>
	   <input type="text" name="email"class="form-control">
	   </div>
<div class="form-group">
	   <label for="name">PASSWORD:</label>
	   <input type="password" name="password" class="form-control">
	   </div>
	   <button type="submit"  class="btn btn-danger">LOGIN</button>
	   </form>
</div>
</div>
</div>


<div class="container-fluid" id="c">
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\project-app\resources\views/index1.blade.php ENDPATH**/ ?>