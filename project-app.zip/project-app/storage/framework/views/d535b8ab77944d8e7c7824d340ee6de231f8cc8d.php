<html>
<head>
<title>form creater</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo e(url('public/assets/css/bootstrap.min.css')); ?>">
<script src="<?php echo e(url('public/assets/js/jquery-3.6.0.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/css/bootstrap.min.js')); ?>"></script>
<style>
*
{
	color:green;
	font-size:20px;
}
#a
{
width:100%;
height:600px;
background-image:url("<?php echo e(url('public/assets/image/ph2.jpg')); ?>");
}
#b
{
width:100%;
height:300px;
background-image:url("<?php echo e(url('public/assets/image/ph1.jpg')); ?>");
}


</style>
</head>
<body>
<div class="container-fluid" id="b">
</div>
<div class="container-fluid" id="a">
<div class="row">
<div class="col-md-4">
     <form action="<?php echo e(url('/insert')); ?>" method="post" enctype="multipart/form-data">
	  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	  <input type="hidden" name="id">
	   <div class="form-group">
	   <label for="task">TASK TITLE:</label>
	   <input type="text" name="task" id="task" required  class="form-control">
	   </div>
	    <div class="form-group">
	   <label for="date">DATE:</label>
	   <input type="date" name="date" id="date" required  class="form-control">
	   </div>
	    <div class="form-group">
	   <label for="start">START TIME:</label>
	   <input type="time" name="start" id="start"required  class="form-control">
	   </div>
	    <div class="form-group">
	   <label for="end">END TIME:</label>  
	   <input type="time" name="end"id="end"required  class="form-control">
	   </div>
	   <button type="submit"  class="btn btn-danger">SUBMIT</button>
	   </form>
	   </div>
</div>
</div>
<div class="container-fluid" >
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\project-app\resources\views/page2.blade.php ENDPATH**/ ?>