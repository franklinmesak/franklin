<html>
<head>
<title>form creater</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo e(url('public/assets/css/bootstrap.min.css')); ?>">
<script src="<?php echo e(url('public/assets/js/jquery-3.6.0.js')); ?>"></script>
<script src="<?php echo e(url('public/assets/css/bootstrap.min.js')); ?>"></script>
<style>
#a
{
width:100%;
height:600px;
background-image:url("<?php echo e(url('public/assets/image/ph2.jpg')); ?>");
}
#b
{
width:100%;
height:300px;
background-image:url("<?php echo e(url('public/assets/image/ph1.jpg')); ?>");
}
*
{
	color:red;
	font-size:20px;
}
</style>
</head>
<body>
<div class="container-fluid" id="b">
</div>

<div id="page-wrapper">
        <div class="graphs">
	   <h1>ADD STAFF</h1>
	 <table id="example" class="table table-striped table-bordered nowrap" cellspacing="0" width="100%">
					<thead>
						<tr>
							<th>task</th>
							<th>date</th>
							<th>start</th>
				            <th>end</th>
							<th>status</th>
							<th>approval</th>
						    <th>reject</th>
						</tr>
					</thead>
                <tbody>
      			<?php $__currentLoopData = $view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
						<tr>
							<td><?php echo e($hell->task); ?></td>
							<td><?php echo e($hell->date); ?></td>
							<td><?php echo e($hell->start); ?></td>
							<td><?php echo e($hell->end); ?></td>
							<td><?php echo e($hell->status); ?></td>
							
							<td><a href="<?php echo e(url('/approval/'.$hell->id)); ?>">approval</a></td>
							<td><a href="<?php echo e(url('/reject/'.$hell->id)); ?>">reject</a></td>
							
						</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
              </table>
			  </div>
			  </div>
</div>
<div class="container-fluid">
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\project-app\resources\views/page1.blade.php ENDPATH**/ ?>